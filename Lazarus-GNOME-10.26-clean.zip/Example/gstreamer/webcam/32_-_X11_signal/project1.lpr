
program project1;

uses
  unixtype,
  ctypes,
  xlib,
  x,
  xutil,
  keysym,
  fp_glib2,
  fp_gst_app,
  fp_gst;

const
  EventMask = KeyPressMask or ExposureMask or PointerMotionMask or ButtonPressMask;

type
  TWinData = record
    dis: PDisplay;
    win: TWindow;
    gc: TGC;
    visual: PVisual;
    image: PXImage;
  end;
  PWinData = ^TWinData;

  // https://stackoverflow.com/questions/69747987/gstreamer-rtsp-tee-appsink-cant-emit-signal-new-sample

  function new_prerollb(appsink: PGstAppSink; user_data: Tgpointer): TGstFlowReturn;
  var
    winData: PWinData absolute user_data;
    sample: PGstSample;
    caps: PGstCaps;
    structure: PGstStructure;
    w, h: Tgint;
  begin
    sample := gst_app_sink_pull_preroll(appsink);
    if sample = nil then begin
      WriteLn('No sample');
      Exit(GST_FLOW_OK);
    end;

    caps := gst_sample_get_caps(sample);
    if caps <> nil then begin
      structure := gst_caps_get_structure(caps, 0);
      if gst_structure_get_int(structure, 'width', @w) and gst_structure_get_int(structure, 'height', @h) then begin
        WriteLn(w, ' x ', h);
      end;
    end;

    with windata^ do begin
      image := XCreateImage(dis, visual, 24, ZPixmap, 0, nil, w, h, 32, 0);
    end;

    gst_sample_unref(sample);
    Exit(GST_FLOW_OK);
  end;

  function on_new_sample(appsink: PGstAppSink; user_data: Tgpointer): TGstFlowReturn;
  var
    winData: PWinData absolute user_data;
    sample: PGstSample;
    buffer: PGstBuffer;
    map: TGstMapInfo;
    attr: TXWindowAttributes;
  begin
    sample := gst_app_sink_pull_sample(appsink);
    if sample = nil then begin
      WriteLn('No sample');
      Exit(GST_FLOW_ERROR);
    end;

    buffer := gst_sample_get_buffer(sample);
    gst_buffer_map(buffer, @map, GST_MAP_READ);

    with winData^ do begin
      image^.Data := pansichar(map.Data);
      XGetWindowAttributes(dis, win, @attr);
      XPutImage(dis, win, gc, image, 0, 0, 0, 0, attr.width, attr.height);
    end;

    gst_buffer_unmap(buffer, @map);
    gst_sample_unref(sample);

    Exit(GST_FLOW_OK);
  end;


  procedure main;
  var
    windata: TWinData;
    Event: TXEvent;
    scr: cint;
    pipeline, appsink: PGstElement;

  begin
    windata := Default(TWinData);
    FillChar(windata, SizeOf(windata), 0);

    // X11

    with windata do begin
      dis := XOpenDisplay(nil);
      if dis = nil then begin
        WriteLn('Kann nicht das Display öffnen');
        Halt(1);
      end;
      scr := DefaultScreen(dis);
      gc := DefaultGC(dis, scr);
      win := XCreateSimpleWindow(dis, RootWindow(dis, scr), 10, 10, 640, 480, 1, 0, $444444);
      visual := DefaultVisual(dis, scr);
      gc := XCreateGC(dis, win, 0, nil);
      XStoreName(dis, win, 'Webcam-Fenster');
      XSelectInput(dis, win, EventMask);
      XMapWindow(dis, win);
    end;

    // === GST

    gst_init(@argc, @argv);

    pipeline := gst_parse_launch('v4l2src ! videoconvert ! video/x-raw,format=BGRA ! appsink name=sink emit-signals=true sync=false', nil);
    if pipeline = nil then begin
      WriteLn('pipeline error');
    end;

    appsink := gst_bin_get_by_name(GST_BIN(pipeline), 'sink');
    if appsink = nil then begin
      WriteLn('sink error');
      Halt;
    end;

    g_signal_connect(appsink, 'new-preroll', G_CALLBACK(@new_prerollb), @windata);
    g_signal_connect(appsink, 'new-sample', G_CALLBACK(@on_new_sample), @windata);
    gst_element_set_state(pipeline, GST_STATE_PLAYING);

    while (True) do begin
      if XPending(windata.dis) > 0 then begin
        XNextEvent(windata.dis, @Event);
        case Event._type of
          Expose: begin
          end;
          ButtonPress: begin
            XRaiseWindow(windata.dis, Event.xbutton.window);
          end;
          KeyPress: begin
            if XLookupKeysym(@Event.xkey, 0) = XK_Escape then begin
              Break;
            end;
          end;
        end;
      end;
    end;

    with windata do begin
      gst_object_unref(appsink);
      gst_object_unref(pipeline);

      XDestroyWindow(dis, win);
      XCloseDisplay(dis);
    end;
  end;

begin
  main;
end.
