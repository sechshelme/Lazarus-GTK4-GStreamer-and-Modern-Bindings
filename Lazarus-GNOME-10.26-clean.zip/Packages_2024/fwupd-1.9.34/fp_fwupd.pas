unit fp_fwupd;

interface

uses
  fp_glib2;

const
  {$IFDEF Linux}
  libfwupd = 'fwupd';
  {$ENDIF}

  {$IFDEF Windows}
  {$FATAL  no supported}
  {$ENDIF}

  {$IFDEF FPC}
  {$PACKRECORDS C}
  {$ENDIF}

  {$DEFINE read_enum}
  {$include fp_fwupd_includes.inc}
  {$UNDEF read_enum}

  {$DEFINE read_struct}
  {$include fp_fwupd_includes.inc}
  {$UNDEF read_struct}

  {$DEFINE read_function}
  {$include fp_fwupd_includes.inc}
  {$UNDEF read_function}

implementation

{$DEFINE read_implementation}
{$include fp_fwupd_includes.inc}
{$UNDEF read_implementation}

end.
