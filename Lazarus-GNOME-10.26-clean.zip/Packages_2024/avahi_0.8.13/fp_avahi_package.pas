{ This file was automatically created by Lazarus. Do not edit!
  This source is only used to compile and install the package.
 }

unit fp_avahi_package;

{$warn 5023 off : no warning about unused units}
interface

uses
  fp_avahi_common, fp_avahi_client, fp_avahi_glib, fp_avahi_gobject, 
  fp_avahi_core, LazarusPackageIntf;

implementation

procedure Register;
begin
end;

initialization
  RegisterPackage('fp_avahi_package', @Register);
end.
