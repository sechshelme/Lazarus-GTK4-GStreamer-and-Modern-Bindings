unit fp_GL_Tools;

interface

uses
  fp_epoxy;

type
  PShader = type Pointer;

function shader_new: PShader; cdecl;
function shader_get_ID(shader: PShader): TGLint; cdecl;
function shader_load_shaderobject(shader: PShader; shaderType: TGLenum; AShader: pchar): boolean; cdecl;
function shader_link_program(shader: PShader): boolean; cdecl;
function shader_get_errortext(shader: PShader): pchar; cdecl;
procedure shader_use_program(shader: PShader); cdecl;
function shader_uniform_location(shader: PShader; ch: pchar): TGLint; cdecl;
function shader_uniform_blockindex(shader: PShader; ch: pchar): TGLuint; cdecl;
function shader_attrib_location(shader: PShader; ch: pchar): TGLint; cdecl;
procedure shader_unref(shader: PShader); cdecl;

implementation

type
  TShaderPrivat = record
    FProgramObject: TGLint;
    error_text: pchar;
  end;
  PShaderPrivat = ^TShaderPrivat;

function shader_new: PShader; cdecl;
var
  sh: PShaderPrivat absolute Result;
begin
  sh := GetMem(SizeOf(TShaderPrivat));
  sh^.FProgramObject := glCreateProgram();
  sh^.error_text := nil;
end;

function shader_get_ID(shader: PShader): TGLint; cdecl;
var
  sh: PShaderPrivat absolute shader;
begin
  Result := sh^.FProgramObject;
end;

function shader_load_shaderobject(shader: PShader; shaderType: TGLenum; AShader: pchar): boolean; cdecl;
var
  sh: PShaderPrivat absolute shader;
  ShaderObject: TGLint;
  l: TGLint;

  ErrorStatus: TGLboolean;
  InfoLogLength: TGLsizei;
begin
  Result := True;
  ShaderObject := glCreateShader(shaderType);

  l := Length(AShader);
  glShaderSource(ShaderObject, 1, @AShader, @l);
  glCompileShader(ShaderObject);
  glAttachShader(sh^.FProgramObject, ShaderObject);

  // Check  Shader
  glGetShaderiv(ShaderObject, GL_COMPILE_STATUS, @ErrorStatus);
  glGetShaderiv(ShaderObject, GL_INFO_LOG_LENGTH, @InfoLogLength);
  if sh^.error_text <> nil then begin
    Freemem(sh^.error_text);
  end;
  sh^.error_text := AllocMem(InfoLogLength + 1);
  glGetShaderInfoLog(ShaderObject, InfoLogLength, nil, sh^.error_text);

  if ErrorStatus = GL_FALSE then begin
    Result := False;
  end;

  glDeleteShader(ShaderObject);
end;

function shader_link_program(shader: PShader): boolean; cdecl;
var
  sh: PShaderPrivat absolute shader;
  ErrorStatus: TGLboolean;
  InfoLogLength: TGLsizei;
begin
  Result := True;
  glLinkProgram(sh^.FProgramObject);

  // Check  Link
  glGetProgramiv(sh^.FProgramObject, GL_LINK_STATUS, @ErrorStatus);

  if ErrorStatus = GL_FALSE then begin
    Result := False;
    glGetProgramiv(sh^.FProgramObject, GL_INFO_LOG_LENGTH, @InfoLogLength);
    if sh^.error_text <> nil then begin
      Freemem(sh^.error_text);
    end;
    sh^.error_text := AllocMem(InfoLogLength + 1);
    glGetProgramInfoLog(sh^.FProgramObject, InfoLogLength, nil, pchar(sh^.error_text));
  end;
end;

function shader_get_errortext(shader: PShader): pchar; cdecl;
var
  sh: PShaderPrivat absolute shader;
begin
  Result := sh^.error_text;
end;

procedure shader_use_program(shader: PShader); cdecl;
var
  sh: PShaderPrivat absolute shader;
begin
  glUseProgram(sh^.FProgramObject);
end;

function shader_uniform_location(shader: PShader; ch: pchar): TGLint; cdecl;
var
  sh: PShaderPrivat absolute shader;
begin
  Result := glGetUniformLocation(sh^.FProgramObject, ch);
end;

function shader_uniform_blockindex(shader: PShader; ch: pchar): TGLuint; cdecl;
var
  sh: PShaderPrivat absolute shader;
begin
  Result := glGetUniformBlockIndex(sh^.FProgramObject, ch);
end;

function shader_attrib_location(shader: PShader; ch: pchar): TGLint; cdecl;
var
  sh: PShaderPrivat absolute shader;
begin
  Result := glGetAttribLocation(sh^.FProgramObject, ch);
end;

procedure shader_unref(shader: PShader); cdecl;
var
  sh: PShaderPrivat absolute shader;
begin
  glDeleteProgram(sh^.FProgramObject);
  if sh^.error_text <> nil then begin
    Freemem(sh^.error_text);
  end;
  Freemem(sh);
end;

end.
