unit fp_apriltag;

interface

const
  {$IFDEF Linux}
  libc = 'c';
  libapriltag = 'apriltag';
  libapriltag_utils = 'apriltag-utils';
  {$ENDIF}

  {$IFDEF Windows}
  libc = 'msvcrt.dll';
  libapriltag = 'apriltag.dll';
  libapriltag_utils = 'apriltag-utils.dll';
  {$ENDIF}

type
  Tuint8_t = uint8;
  Puint8_t = ^Tuint8_t;
  PPuint8_t = ^Puint8_t;
  Tuint16_t = uint16;
  Puint16_t = ^Tuint16_t;
  PPuint16_t = ^Puint16_t;
  Tuint32_t = uint32;
  Puint32_t = ^Tuint32_t;
  PPuint32_t = ^Puint32_t;
  Tuint64_t = uint64;
  Puint64_t = ^Tuint64_t;
  PPuint64_t = ^Puint64_t;

  Tint8_t = int8;
  Pint8_t = ^Tint8_t;
  PPint8_t = ^Pint8_t;
  Tint16_t = int16;
  Pint16_t = ^Tint16_t;
  PPint16_t = ^Pint16_t;
  Tint32_t = int32;
  Pint32_t = ^Tint32_t;
  PPint32_t = ^Pint32_t;
  Tint64_t = int64;
  Pint64_t = ^Tint64_t;
  PPint64_t = ^Pint64_t;

  Tsize_t = SizeUInt;

  Ptimeval = type Pointer;
  Ptimespec = type Pointer;
  PFILE = type Pointer;
  Tva_list = Pointer; // ??????

  // am ende umbennen
  Tbool = boolean;
  Tdouble = double;



type
  Tcompar_fn_t = function(para1: pointer; para2: pointer): longint; cdecl;

procedure qsort(base: pointer; nmemb: Tsize_t; size: Tsize_t; compar: Tcompar_fn_t); cdecl; external libc;
function calloc(nmemb: Tsize_t; size: Tsize_t): pointer; cdecl; external libc;
procedure free(ptr: pointer); cdecl; external libc;
function memcpy(dest: pointer; src: pointer; n: Tsize_t): pointer; cdecl; external libc;
function strncpy(dest: pchar; src: pchar; n: Tsize_t): pchar; cdecl; external libc;
function printf(format: pchar): longint; cdecl; varargs; external libc;
function memset(s: pointer; c: longint; n: Tsize_t): pointer; cdecl; external libc;
function malloc(size: Tsize_t): pointer; cdecl; external libc;
function realloc(ptr: pointer; size: Tsize_t): pointer; cdecl; external libc;
function memmove(dest: pointer; src: pointer; n: Tsize_t): pointer; cdecl; external libc;
function memcmp(s1: pointer; s2: pointer; n: Tsize_t): longint; cdecl; external libc;
function fprintf(f: Pointer; format: pchar): integer; cdecl; varargs; external libc;


{$IFDEF FPC}
{$PACKRECORDS C}
{$ENDIF}

{$DEFINE read_interface}
{$include fp_apriltag_includes.inc}
{$UNDEF read_interface}

implementation

{$DEFINE read_implementation}
{$include fp_apriltag_includes.inc}
{$UNDEF read_implementation}

// wegen "division_by_zero" in den clibs
{$IF defined(CPUX86) or defined(CPUX64)}
{$asmmode intel}
procedure SetMXCSR;
var
  w2: word = 8064;
begin
  asm
           Ldmxcsr w2
  end;
end;
{$ENDIF}

begin
  {$IF defined(CPUX86) or defined(CPUX64)}
  SetMXCSR;
  {$ENDIF}
end.
