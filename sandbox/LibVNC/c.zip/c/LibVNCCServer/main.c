


// gcc main.c -o main `pkg-config --cflags --libs sdl2` -lvncclient -lvncserver

// virt-viewer --connect vnc://127.0.0.1:5901

// remote-viewer vnc://127.0.0.1:5901




#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <rfb/rfb.h>

int main(int argc, char* argv[]) {
    int width = 640;
    int height = 480;
    int bpp = 4; // 4 Bytes pro Pixel (32-bit ARGB)

    // 1. Framebuffer reservieren
    uint32_t* framebuffer = malloc(width * height * bpp);
    if (!framebuffer) {
        fprintf(stderr, "Konnte Speicher für Framebuffer nicht reservieren.\n");
        return 1;
    }
    memset(framebuffer, 0, width * height * bpp);

    // 2. LibVNCServer initialisieren
    rfbScreenInfoPtr server = rfbGetScreen(&argc, argv, width, height, 8, 3, bpp);
    if (!server) {
        free(framebuffer);
        return 1;
    }

    server->frameBuffer = (char*)framebuffer;
    server->desktopName = "Mein eigener C-VNC-Server";
    server->port = 5901; 
    server->ipv6port = 5901; // Verhindert Port-Konflikte im Dual-Stack

    rfbInitServer(server);

    printf("VNC-Server läuft auf Port %d...\n", server->port);

    // Animations-Variablen
    int box_x = 50, box_y = 50;
    int box_size = 100;
    int speed_x = 4, speed_y = 3;

    // 3. Hauptschleife
    while (rfbIsActive(server)) {
        
        // Bildschirm leeren
        memset(framebuffer, 0, width * height * bpp);

        // Position für den nächsten Frame berechnen
        box_x += speed_x;
        box_y += speed_y;

        // KORREKTUR: Kollision prüfen UND Position sofort einschränken,
        // damit wir NIEMALS ausserhalb des Arrays zeichnen!
        if (box_x < 0) { box_x = 0; speed_x = -speed_x; }
        if (box_x + box_size > width) { box_x = width - box_size; speed_x = -speed_x; }
        
        if (box_y < 0) { box_y = 0; speed_y = -speed_y; }
        if (box_y + box_size > height) { box_y = height - box_size; speed_y = -speed_y; }

        // Das Quadrat sicher zeichnen
        for (int y = box_y; y < box_y + box_size; y++) {
            for (int x = box_x; x < box_x + box_size; x++) {
                int pixel_index = y * width + x;
                framebuffer[pixel_index] = 0x000000FF; // Blau
            }
        }

        // Updates signalisieren
        rfbMarkRectAsModified(server, 0, 0, width, height);

        // Netzwerk-Events abarbeiten (20ms)
        rfbProcessEvents(server, 20000);
    }

    rfbScreenCleanup(server);
    free(framebuffer);
    return 0;
}

