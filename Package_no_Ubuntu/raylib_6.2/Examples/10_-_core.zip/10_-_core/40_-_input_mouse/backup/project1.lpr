program project1;

uses
  fp_raylib;

  procedure main;
  const
    screenWidth = 800;
    screenHeight = 450;
  var
    ballPosition: TVector2 = (items: (screenWidth / 2, screenHeight / 3));
    ballColor: TColor;
  begin
    InitWindow(screenWidth, screenHeight, 'raylib [core] example - input mouse');
    SetTargetFPS(60);
    ballColor := DARKBLUE;

    while not WindowShouldClose do begin
      if IsKeyDown(KEY_H) then begin
        if IsCursorHidden then ShowCursor
        else HideCursor();      end;

      if IsMouseButtonPressed(MOUSE_BUTTON_LEFT)then ballColor := MAROON
      else if IsMouseButtonPressed(MOUSE_BUTTON_MIDDLE)then ballColor := LIME
      else if IsMouseButtonPressed(MOUSE_BUTTON_RIGHT)then ballColor := DARKBLUE
      else if IsMouseButtonPressed(MOUSE_BUTTON_SIDE)then ballColor := PURPLE
      else if IsMouseButtonPressed(MOUSE_BUTTON_EXTRA)then ballColor := YELLOW
      else if IsMouseButtonPressed(MOUSE_BUTTON_FORWARD)then ballColor := ORANGE
      else if IsMouseButtonPressed(MOUSE_BUTTON_BACK)then ballColor := BEIGE;

      BeginDrawing;
      ClearBackground(RAYWHITE);

       DrawCircleV(ballPosition, 40, ballColor);

       DrawText('move ball with mouse and click mouse button to change color', 10, 10, 20, DARKGRAY);
       DrawText('Press ''H'' to toggle cursor visibility', 10, 30, 20, DARKGRAY);

       if IsCursorHidden then DrawText('CURSOR HIDDEN', 20, 60, 20, RED)
       else DrawText('CURSOR VISIBLE', 20, 60, 20, LIME);
       EndDrawing;
    end;
    CloseWindow;
  end;

begin
  main;
end.
